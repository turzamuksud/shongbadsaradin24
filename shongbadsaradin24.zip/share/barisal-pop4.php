<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Nextline Firm">

    <title>shongbadsharadin24.com</title>
    <link rel="icon" href="../img/logo.png">

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/shop-homepage.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/"><img src="../img/logo.png" height="50px;" width="400px;" style="margin-top: -12px;"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="float: right;">
                <ul class="nav navbar-nav">
                    <li><a href="../index.php">হোম</a></li>
                    <li><a href="../national.php">জাতীয়</a></li>
                    <li><a href="../politics.php">রাজনীতি</a></li>
                    <li><a href="../entertainment.php">বিনোদন</a></li>
                    <li><a href="../business.php">ব্যবসা</a></li>
                    <li><a href="../literature.php">সাহিত্য</a></li>
                    <li><a href="../sports.php">খেলা</a></li>
                    <li><a href="../others.php">অন্যান্য</a></li>
                    <li>
                      <div class="dropdown" style="margin-top: 15px;">
                        <a class="dropbtn" style="text-decoration: none;">দেশ<span class="caret"></span></a>
                        <div class="dropdown-content" style="padding-top:15px;">
                          <a href="../dhaka.php">ঢাকা</a>
                          <a href="../chittagong.php">চট্টগ্রাম</a>
                          <a href="../khulna.php">খুলনা</a>
                          <a href="../rajshahi">রাজশাহী</a>
                          <a href="../barisal.php">বরিশাল</a>
                          <a href="../sylhet.php">সিলেট</a>
                          <a href="../rangpur.php">রংপুর</a>
                          <a href="../mymensingh.php">ময়মনসিংহ</a>
                        </div>
                      </div>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
        <marquee scolldelay="50" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
            <p id="demo" style="margin-top: 10px; color: white;"></p>
        </marquee>
        <script>
            document.getElementById("demo").innerHTML = Date();
        </script>
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">


        </div>

    </div>
    <!-- /.container -->

    <div class="container">


    <!-- kolam popup -->
    <div>
      <div class="">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">

            <?php
                                        $con = mysqli_connect("localhost","subichar_root","123456aA","subichar_shongbadsaradin24");
                                    // Check connection
                                    if (mysqli_connect_error())
                                            {
                                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                            }
                                                else {
                                                    $sql="SELECT id FROM barisal";
                                                    $result=mysqli_query($con,$sql);
                                                    $rowcount=mysqli_num_rows($result);

                                                    $sql = "SELECT * FROM barisal WHERE id=$rowcount-3";
                                                    $result = $con->query($sql);

                                            if ($result->num_rows > 0) {
                                                            // output data of each row
                                                        while($res=mysqli_fetch_array($result)) {
                                                                            
                                                            echo '<img src="data:image/jpeg;base64,'.base64_encode( $res['image'] ).'"  class="slide-image" alt="image" style="max-height: 300px; max-width: 800px;"/>';
                                            ?>
                                             <p style="background-color: lightgray;"><?php echo  $res['image_note']; ?></p>
                                             <h4 class="modal-title"><?php echo  $res['head']; ?></h4>
                                              </div>
                                              <div class="modal-body">
                                                <p align="justify">

                                                <br><br><?php echo  $res['body']; ?></p>
                                              </div>
                                                                               
                                        <?php

                                                            }
                                            } else {
                                                            echo "Under Maintenance!!";
                                            }

                                        }

                                        $con->close();
                                ?>

            
          <div class="modal-footer">
          </div>
        </div>

      </div>
    </div>

   

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <marquee scolldelay="50" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
                    <div class="col-lg-12">
                        <p>Copyright &copy; <a href="http://nextlinefirm.com/" style="text-decoration: none; color: green;"><img src="img/nxt_logo.png" height="25px;" width="50px;"></a> 2017</p>
                    </div>
                </marquee>
                <marquee scolldelay="50" direction="right" onmouseover="this.stop();" onmouseout="this.start();">
                    <div class="col-lg-12">
                        <p>Developed by <a href="http://shongbadsaradin24.com/turza_muksud/" style="text-decoration: none; color: green;"><img src="img/turza_logo.png" height="50px;" width="110px;">&#8482;</a></p>
                    </div>
                </marquee>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>





</body>

</html>
