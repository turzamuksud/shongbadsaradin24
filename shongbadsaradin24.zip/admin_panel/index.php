<?php
include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $_SESSION['username']; ?></title>
		<center><h1>Admin Panel</h1></center>
		
		<link rel="stylesheet" href="css/style.css" />
	</head>
<body>
	<a href="logout.php" style="float: right; margin-right: 10%; margin-left: 20px; margin-top: -20px;">Logout</a>
	<p style="float: left; margin-left: 10%; margin-right: 20px; margin-top: -20px;">Welcome <?php echo $_SESSION['username']; ?>!</p>

	<div style="border: 1px solid black; margin-top: 40px;">
		<center>
			<a href="slider.php""><button style="height: 50px; width: 150px; margin: 20px; color: green;">Update Slider</button></a>
			<a href="kolam.php"><button style="height: 50px; width: 150px; margin: 20px; color: green;">Update Kolam</button></a>
			<a href="home.php"><button style="height: 50px; width: 150px; margin: 20px; color: green;">Update Home news</button></a>
		</center>
	</div>
	<div style="border: 1px solid black; margin-top: 25px;">
		<center>
			<a href="national.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update National news</button></a>
			<a href="politics.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update Politics news</button></a>
			<a href="entertainment.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update Entertainment news</button></a>
			<a href="business.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update Business news</button></a>
			<a href="sports.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update Sports news</button></a>
			<a href="literature.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update Literature news</button></a>
			<a href="others.php"><button style="height: 50px; width: 190px; margin: 20px; color: green;">Update Others news</button></a>
		</center>
	</div>
	<div style="border: 1px solid black; margin-top: 25px;">
		<center>
			<a href="desh_dhaka.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Dhaka news</button></a>
			<a href="desh_chittagong.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Chittagong news</button></a>
			<a href="desh_rangpur.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Rangpur news</button></a>
			<a href="desh_mymensingh.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Mymensingh news</button></a>
			<a href="desh_khulna.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Khulna news</button></a>
			<a href="desh_rajshahi.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Rajshahi news</button></a>
			<a href="desh_barisal.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Barisal news</button></a>
			<a href="desh_sylhet.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Update Country Sylhet news</button></a>
		</center>
	</div>

	<div style="border: 1px solid black; margin-top: 25px;">
		<center>
			<a href="ads1.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Advertisement 728*90</button></a>
			<a href="ads2.php"><button style="height: 50px; width: 150px; margin: 20px;color: green;">Advertisement 200*100</button></a>
		</center>
	</div>



</body>
</html>
