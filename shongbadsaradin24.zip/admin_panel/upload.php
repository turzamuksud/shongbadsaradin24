<!DOCTYPE html>
<html>

<body>



<?php
                                        $con = mysqli_connect("localhost","subichar_root","123456aA","subichar_shongbadsaradin24");
                                    // Check connection
                                    if (mysqli_connect_error())
                                            {
                                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                            }
                                                else {
                                                    $sql="SELECT id FROM kolam";
                                                    $result=mysqli_query($con,$sql);
                                                    $rowcount=mysqli_num_rows($result);

                                                    $sql = "SELECT * FROM kolam WHERE id=$rowcount";
                                                    $result = $con->query($sql);

                                            if ($result->num_rows > 0) {
                                                            // output data of each row
                                                        while($res=mysqli_fetch_array($result)) {
                                                                            
                                                            echo '<img src="data:image/jpeg;base64,'.base64_encode( $res['image'] ).'" alt="image" style="max-height:100px; max-width:200px;"/>';
                                            ?>
                                            <p style="float: left;"><?php echo  $res['head']; ?></p>
                                            
<a href="" onClick="popitup('<?php  echo  $res['head'];?>')">Open</a>
                                        <?php

                                                            }
                                            } else {
                                                            echo "Under Maintenance!!";
                                            }

                                        }

                                        $con->close();
                                ?>




                                <script type="text/javascript">
function popitup(url) {
newwindow=window.open(url);
if (window.focus) {newwindow.focus()}
return false;
}
</script>

                                </body>
                                </html>