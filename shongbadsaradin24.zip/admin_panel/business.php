<?php
/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/

include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $_SESSION['username']; ?></title>
<center><h1>Admin Panel</h1></center>
<a href="logout.php" style="float: right; margin-right: 10%; margin-left: 20px;">Logout</a>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<p style="float: left; margin-left: 10%; margin-right: 20px;">Welcome <?php echo $_SESSION['username']; ?>!</p>
<center>
	<div style="width: 80%; margin-top: 80px;">
		<fieldset>
			<legend><h3>Business news..</h3></legend>
			<form action="" method="post" enctype="multipart/form-data">
				<h4>Upload Image</h4>
				<input type="file" name="image"><br><br>
				<textarea name="cap" style="width: 70%;">Image caption</textarea><br><br>
				<textarea name="head" style="width: 80%;">News heading</textarea><br><br>
				<textarea name="body" style="width: 80%; height: 100px;">News body</textarea><br>
				<input type="submit" name="submit1" value="Upload">
			</form>
		</fieldset>
	</div>
</center>


<?php

if(isset($_POST['submit1']))
            {
				$conn = new PDO('mysql:host=localhost; dbname=subichar_shongbadsaradin24','subichar_root', '123456aA'); 

				$img=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "INSERT INTO business(image, image_note, head, body) VALUES ('$img', '".$_POST["cap"]."', '".$_POST["head"]."', '".$_POST["body"]."')";
				 
				$conn->exec($sql);
				echo "<script>alert('Successfully Added!!!'); window.location='index.php'</script>";
            }  
?>
</body>
</html>
