<!DOCTYPE html>
<html>

<body>

<form method="post" action=""  enctype="multipart/form-data">
    <input type="file" name="image">
    <button type="submit" name="Submit" class="btn btn-primary">Upload</button>
</form>

<?php 
				$conn = new PDO('mysql:host=localhost; dbname=subichar_shongbadsaradin24','subichar_root', '123456aA'); 
if (isset($_POST['Submit'])) {
       
$location=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));


$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "INSERT INTO slider(image) VALUES ('$location')";
 
$conn->exec($sql);
echo "<script>alert('Successfully Added!!!'); window.location='index.php'</script>";
}
?>
</body>
</html>

